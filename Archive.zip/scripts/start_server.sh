#objective: instructs application to start on VM 
service httpd start